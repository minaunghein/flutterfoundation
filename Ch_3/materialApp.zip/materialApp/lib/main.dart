import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:simple/homescreen.dart';

void main() => runApp(MaterialApp(
  theme: ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.blueGrey
  ),

  darkTheme:ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.deepOrange
  ) ,

  home:Scaffold(
    backgroundColor: Colors.blue,
  ),
  routes: <String,Widget Function(BuildContext context)>{
    '/About': (BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.green,
    );
    },

    '/Offer': (BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.green,
    );
    },
  },
  onGenerateRoute: (RouteSettings settings) {
        //Will execute when unregistered route is requested, setting hold the requested name
        final List<String> pathElements = settings.name.split(
            '/'); //Try to parse '/path/youvalue' and get array, normally it get return first element as ''
        if (pathElements[0] != '') {
          return null;
        }
        if (pathElements[1] == 'something') {
          //Parse for predefined element
          final int index =
              int.parse(pathElements[2]); //parse value (here as int)
          return MaterialPageRoute(
              //need to return a new Route
              builder: (BuildContext context) =>
                 Container()); //Add desire page for certain path & Value
        }
        return null;
      },
      onUnknownRoute: (RouteSettings settings) {
        //Wil execute when onGenerateRoute return null
        return MaterialPageRoute(
            //need to return a new Route
            builder: (BuildContext context) =>
                Container()); //Add desire page for certain path & Value
      },

   

));

 